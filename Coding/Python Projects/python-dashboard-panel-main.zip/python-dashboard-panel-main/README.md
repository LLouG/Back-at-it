# python-dashboard-panel
### Interactive visualization dashboard in Python with Panel

This repo contains code for the portfolio project on my Youtube channel (https://www.youtube.com/watch?v=uhxiXOTKzfs&t=26s)

If you want to see all the dependencies for this project, please see requirements.txt file.

To serve the dashboard locally, use the command:
```
panel serve Interactive_dashboard.ipynb
```

![375CCFBB-71E5-4040-AE2E-A79D9FD04E6E](https://user-images.githubusercontent.com/22730220/157565990-3e36c238-5bda-43d7-8bab-56c9c1984ddb.jpeg)

