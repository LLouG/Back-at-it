def divide(x: int, y: int) -> None:
    print(x / y)


divide(4, 0)  # Throws or Raises an error `ZeroDivisionError`
