# Control Flow 

Topics Covered -

1. If / Else Statements With Python
2. And / OR statements in Python
3. For Loops In Python
4. For and In Loops in Python
5. While Loops in Python
6. Match Operator - New in Python 3.10

## Sequence -

1. driving_license.py
2. alien_license.py
3. print_my_name.py
4. print_nums.py
5. guess_planet.py
6. match_colour.py
7. 🔒 game_save_zortan.py
