from .rectangle import Rectangle
from .circle import Circle
from .square import Square
