from shapes import shapes

c = shapes.Circle(5)
r = shapes.Rectangle(23.12, 45.82)
s = shapes.Square(7.80)

print(c)
print(r)
print(s)
