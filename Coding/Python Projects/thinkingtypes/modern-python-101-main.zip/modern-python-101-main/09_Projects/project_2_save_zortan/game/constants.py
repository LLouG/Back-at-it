"""
CONSTANTS:
----------
This is just a helper module where we can group all constants together. It make it easy
to find and change parameters as required.
"""

NUM_ATTACKS = 3
WIN_MSG = "Avengers successfully saved Zortan!!! ✨ ✨ ✨"
LOST_MSG = "Thanos killed Avengers and captured Zortan!!💀 💀 💀"
