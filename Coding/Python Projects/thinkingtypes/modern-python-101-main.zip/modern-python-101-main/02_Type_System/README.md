# Type System

Topics Covered -

1. Declaring Variables
2. Variable Rules
3. Primitive Data Types

## Sequence -

1. variables.py
2. variable_rules.py
3. primitive_data_types.py
4. string_formatting.py
5. first_bug.py
6. practise.py
